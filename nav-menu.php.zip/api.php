<?php
$url_base = "127.0.0.1:8000";
$api_key = "key_cur_prod_fhhsu5TTSGjhfryusowoki13lsksa";