<!DOCTYPE html>
<html lang="es">

<head>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
</head>

<body>
    <?php include('nav-menu.php') ?>
    <?php include('inicio.php') ?>

    <div id="main-wrapper">

        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <!-- <h5 class="page-title">Estás en: Inicio</h5> -->
                        <div class="d-flex align-items-center">

                        </div>
                    </div>
                    <!-- <div class="col-7 align-self-center">
                        <div class="d-flex no-block justify-content-end align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="index.php">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">Library</li>
                                </ol>
                            </nav>
                        </div>
                    </div> -->
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid" style="background-image: url(assets/img/background.png); background-size: cover;">
                <!-- <div class="row ">
                    <div class="col-lg-12 col-md-10 col-sm-12 text-center"><br><br><br>
                        <h1>BIENVENIDO AL <span style="color: #2c94ea;">PORTAL AEROPORTUARIO</span></h1>
                    </div>
                    <div class="col-lg-12 col-md-10 col-sm-12 text-center">
                        <h2><?php echo $nombre ?> <?php echo $app ?> <?php echo $apm ?></h2>
                        
                    </div>
                    <div class="col-lg-12 col-md-10 col-sm-12 text-center"><br><br>
                        <img src="assets/images/gafsa.bmp" width="75%" alt="">
                    </div>
                </div> -->
                <!-- Navbar -->
                <!-- <nav class="navbar" style="background-color: rgb(218, 238, 255);">
        <div class="container">
            <a class="navbar-brand" href="index.html" style="padding-left: 31vw;">
                <img src="assets/img/humanergy-af.png" alt="Bootstrap" width="220vw">
            </a>
        </div>
    </nav> -->

                <center>

                    <!-- Datos generales de vuelo -->
                    <form method='POST' action='formulario.php' style="width: 90%;">
                        <div class="container" style="padding-top: 3%;">
                            <div class="row">
                                <div class="col-lg-6">
                                    <p style="color: rgb(88, 88, 88); font-size: 1.2rem; font-weight: bold;">
                                        DATOS GENERALES DEL VUELO
                                    </p>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <!-- PRIMER TABLA-->
                                            <div class="input-group input-group-sm mb-3">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue;">Aerolínea</span>
                                                <input id="aereolinea" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="Aeromexico">
                                            </div>
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue;">No. de vuelo</span>
                                                <input id="numVuelo" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="592">
                                            </div>
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue;">Fecha</span>
                                                <input type="date" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="01/12/2023">
                                            </div>
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue;">Aeronave</span>
                                              <!--  <input id="aereonaveI" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="A319-100">-->
                                                <select id="Aeronave" class="form-control" onchange="servPlat();">
                                                <?php   
                                                    $query = $mysqli -> query ("SELECT * FROM gaf_aeronave");
                                                        while ($valores = mysqli_fetch_array($query)) {
                                                        echo '<option value="'.$valores['id'].'">'.$valores['aeronave'].'</option>';
                                                        
                                                        }
                                                    ?>
                                                </select>
                                                <!-- CAMBIO 1-1-->
                                                <?php   
                                                    $query = $mysqli -> query ("SELECT * FROM gaf_aeronave");
                                                        while ($valores = mysqli_fetch_array($query)){                                               
                                                        ?>
                                                        <input type="text" id="aero<?php echo $valores['id'] ?>" value="<?php echo $valores['PMOD'] ?>" style="display:none;">
                                                        <?php
                                                        }
                                                    ?>
                                            </div>
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue;">Matrícula</span>
                                                <input id="matriculaI" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="XA-FAC">
                                            </div>
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue;">Orígen</span>
                                                <input id="origen" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="México">
                                            </div>
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue;">Destino</span>
                                                <input id="destino" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="Tulum">
                                            </div>
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue;">Tipo</span>
                                                <!--<input id="nacionalI" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="Nacional">-->
                                                <select id="tipo" class="form-control" onchange="servPlat();">
                                                <option value="NACIONAL">Nacional</option>
                                                <option value="INTERNACIONAL" selected>Internacional</option>
                                                </select>
                                                <!-- CAMBIO 1-1-->
                                                <?php   
                                                    $query = $mysqli -> query ("SELECT * FROM gaf_serv_complementarios");
                                                        while ($valores = mysqli_fetch_array($query)) {
                                                        ?>
                                                        <input type="text" id="<?php echo $valores['tipo'] ?>" value="<?php echo $valores['tarifa'] ?>" style="display:none;">
                                                        <?php
                                                        }
                                                    ?>
                                            </div>
                                        </div>
                                        <!-- TERMINO DE PRIMER TABLA -->

                                        <!-- COMIENZO 2DA TABLA -->
                                    </div><br>
                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue;">Tipo de cambio</span>
                                                <!--<input id="tipoC" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="17.5">-->
                                                <select id="tipoCambio" class="form-control">
                                                <?php   
                                                    $query = $mysqli -> query ("SELECT * FROM gaf_tipo_cambio");
                                                        while ($valores = mysqli_fetch_array($query)) {
                                                        echo '<option value="'.$valores['cambio'].'">'.$valores['cambio'].'</option>';
                                                        }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue;">Aeropuerto</span>
                                                <!--<input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="PQM">-->
                                                <!-- CATALOGO -->
                                                <select id="aeropuerto" class="form-control">
                                                    <?php
                                                        $query = $mysqli -> query ("SELECT * FROM gaf_aeropuertos ORDER BY id ASC");
                                                        while ($valores = mysqli_fetch_array($query)) {
                                                        echo '<option value="'.$valores['id'].'">'.$valores['iata']." - ".$valores['descripcion'].'</option>';
                                                         }
                                                    ?>
                                                </select>
                                            </div>
                                    <br><br>
                                        <!-- TERMINO 2DA TABLA -->
                                </div>




                                <div class="col-lg-6">
                                    <p style="color: rgb(88, 88, 88); font-size: 1rem; margin-top: -10px; margin-bottom: 3px; font-weight: bold;">
                                        DATOS REQUERIDOS DE MANIFIESTO LLEGADA
                                    </p>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="input-group input-group-sm mb-3">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="height: 23px; background-color: aliceblue;">Hora de entrada a posición
                                                </span>
                                                <input onchange="tiempoP()" id="hentrada" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" >
                                            </div>

                                        </div>
                                    </div>
                                    <!-- cambio -->
                                    <!-- cambio -->,
                                    <!-- cambio -->
                                    <!-- Columna 2 | Datos requeridos salida-->
                                    <p style="color: rgb(88, 88, 88); font-size: 1rem; margin-top: -0px; margin-bottom: 3px; font-weight: bold;">
                                        DATOS REQUERIDOS DE MANIFIESTO SALIDA
                                    </p>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="input-group input-group-sm mb-3">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="height: 23px; background-color: aliceblue;">Orígen
                                                </span>
                                                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;">
                                            </div>
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="height: 23px; background-color: aliceblue;">Destino
                                                </span>
                                                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;">
                                            </div>
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="height: 23px; background-color: aliceblue;">Tipo
                                                </span>
                                                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="Nacional">
                                            </div>
                                            <!-- CAMBIO -->
                                            <!-- CAMBIO -->
                                            <!-- CAMBIO -->
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="height: 23px; background-color: aliceblue;">Pasajeros de Salida
                                                    Nacionales
                                                </span>
                                                <input oninput="calculoTUA();equipaje()" id="pasaNac" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="">
                                            </div>
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="height: 23px; background-color: aliceblue;">Pasajeros de Salida
                                                    Internacionales
                                                </span>
                                                <input onchange="calculoTUA();equipaje()" id="pasaInter" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="">
                                            </div>
                                            <!-- CAMBIO -->
                                            <!-- CAMBIO -->
                                            <!-- CAMBIO -->
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="height: 23px; background-color: aliceblue;">Pasajeros Exentos Nacionales
                                                </span>
                                                <input  onchange="calculoTUA();equipaje()" id="exeNac" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;">
                                            </div>
                                           
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="height: 23px; background-color: aliceblue;">Pasajeros Exentos
                                                    Internacionales
                                                </span>
                                                <input  onchange="calculoTUA();equipaje()" id="exeInt" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;">
                                            </div>
                                            <!-- cambio -->
                                            <!-- cambio -->
                                            <!-- cambio -->
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="height: 23px; background-color: aliceblue;">Hora de salida a posición
                                                </span>
                                                <input onchange="tiempoP()" id="hsalida" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;">
                                            </div>
                                            <!-- cambio -->
                                            <!-- cambio -->
                                            <!-- cambio -->
                                            <!-- cambio -->
                                            
                                        </div>
                                    </div>

                                    <!-- Columna 2 | Datos requeridos pernocta-->
                                    <p style="color: rgb(88, 88, 88); font-size: 1rem; font-weight: bold;">
                                        DATOS REQUERIDOS PERNOCTA
                                    </p>

                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="height: 23px; background-color: aliceblue;">Dia inicio de pernocta
                                                </span>
                                                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="17/12/2023" id="fechaI" onchange="pernocta()">
                                            </div>
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="height: 23px; background-color: aliceblue;">Hora de Inicio de pernocta
                                                </span>
                                                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="19:00:00" id="horaI" onchange="pernocta()">
                                            </div>
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="height: 23px; background-color: aliceblue;">Dia término de pernocta
                                                </span>
                                                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="18/12/2023" id="fechaT" onchange="pernocta()">
                                            </div>
                                            <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                <span class="input-group-text" id="inputGroup-sizing-sm" style="height: 23px; background-color: aliceblue;">Hora de término de pernocta
                                                </span>
                                                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="08:00:00" id="horaT" onchange="pernocta()">
                                            </div>
                                        </div>
                                    </div>

                                    <!-- <input type=image src="assets/img/btn-enviar.png" type="submit" width="28%" alt=""> -->
                                </div>
                                <br><br><br>
                            </div>
                            <hr>
                        </div>


                        <!-- DATOS BASE CALCULADOS -->
                        <section style="background-color: rgba(0, 44, 56, 0);">
                            <center><br>
                                <div class="container">
                                    <div class="row">
                                        <p style="color: #585858; font-size: 1.2rem; font-weight: bold;">
                                            DATOS BASE CALCULADOS
                                        </p>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-6"><br>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="input-group input-group-sm mb-3">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: #d8dee49a; height: 23px;">Tiempo en plataforma</span>
                                                        <input id="tiempoPl" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: #d8dee49a; height: 23px;">Tiempo pernocta</span>
                                                        <input id="tiempoPer" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: #d8dee49a; height: 23px;">Tiempo de conexión de abordadores mecánicos</span>
                                                        <input id="tiempoAbor" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6"><br>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="input-group input-group-sm mb-3">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: #d8dee49a; height: 23px;">Total de pasajeros TUA
                                                            nacional</span>
                                                        <input id="totalNac" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: #d8dee49a; height: 23px;">Total de pasajeros TUA
                                                            internacional</span>
                                                        <input id="totalInt" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="row">
                                            <p style="color: rgb(88, 88, 88); font-size: 1rem; font-weight: bold;">
                                                NOTA: <span style="font-weight: 400;">El tiempo aquí expresado, es en minutos de
                                                    acuerdo
                                                    a las tarifas autorizadas para el aeropuerto.</span>
                                            </p>
                                        </div><br><br>
                                        <hr><br>
                                    </div>
                                    <div class="row">
                                        <!-- CAMBIO -->
                                        <!-- CAMBIO -->
                                        <!-- CAMBIO -->
                                        <!-- CAMBIO -->
                                        <!-- CAMBIO -->
                                        <!-- CAMBIO -->
                                        <!-- CAMBIO -->
                                        <div class="col-lg-6">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <p style="color: #585858; font-size: 1.2rem; font-weight: bold;">
                                                        ABORDADORES MECÁNICOS
                                                    </p>
                                                    <div class="input-group input-group-sm mb-3">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Tiempo de conexión</span>
                                                        <input  id="tiempoCone" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Periodo de 30 min</span>
                                                        <input  id="periodo30" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Periodo de 15 min</span>
                                                        <input id="periodo15" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Tarifa Autorizada Aeropuerto</span>
                                                        <input id="tarifaAuto" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Total de abordadores mecánicos</span>
                                                        <input oninput="totalAbordadores()" id="totalAbor1" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Total</span>
                                                        <input id="totalA" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <!-- ON CHANGE -->
                                        <!-- CALCULO DE TUA-->
                                        <div class="col-lg-6">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <p style="color: #585858; font-size: 1.2rem; font-weight: bold;">
                                                        CÁLCULO TUA
                                                    </p>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">TUA Pasajeros Internacional</span>
                                                        <input  id="tuaPIR" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">TUA Pasajeros nacional</span>
                                                        <input  id="tuaPNR" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Total TUA Nacional</span>
                                                        <input   id="totalTNR" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Total TUA Internacional</span>
                                                        <input  id="totalTIR" type="text"  class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" >
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Total TUA</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" id="totalTUA">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <!-- ---------------------- -->







                            

                                <div class="row">
                                        <div class="col-lg-6">
                                            
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <p style="color: #585858; font-size: 1.2rem; font-weight: bold;">
                                                        INSPECCIÓN DE EQUIPAJE FACTURADO
                                                    </p>
                                                     <!-- value="<php echo $tn=4.71;?> IEFN=INSPERCCION EQUIPAJE NACIONAL aqui tambien se consulta-->
                                                    <div class="input-group input-group-sm mb-3">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Tarifa Nacional</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" 
                                                        id="tarifaNa" value="" >
                                                        
                                                        
                                                    </div>
                                                     <!--  value="<php echo $ti=0; ?> IEFI=INSPECCION EQUIPAJE INTERNACIONAL aqui se consulta-->
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Tarifa internacional</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="" 
                                                       id="tarifaInt"  value="">
                                                    </div>
                                                    <!--posible quitar -->
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Cantidad de pasajeros</span>
                                                        <input id="totalpas" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder="">
                                                    </div>
                                                     <!--value="<php $total=($psn*$tn)+($psi*$ti)?> Totins = total inspeccion  placeholder="466.29" -->
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Total Inspección</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;"
                                                        id="totalInp">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- y este -->
                                        <div class="col-lg-6">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <p style="color: #585858; font-size: 1.2rem; font-weight: bold;">
                                                        SERVICIO DE ATERRIZAJE
                                                    </p>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Peso máx. Aterrizaje MLW</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder=""
                                                        id="pesoMLW" oninput="aterrizaje()">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Tarifa Vuelo Nacional</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder=""
                                                        id ="precioNa">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Tarifa Vuelo Internacional</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;"
                                                        id="precioIa">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Total Aterrizaje</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" placeholder=""
                                                        id="totalAterrizaje">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>










                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <p style="color: #585858; font-size: 1.2rem; font-weight: bold; line-height: 1rem;">
                                                        SERVICIO EN PLATAFORMA DE EMBARQUE Y DESEMBARQUE
                                                    </p>
                                                    <div class="input-group input-group-sm mb-3">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Peso máx. Operacional de despegue PMOD</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" id="pesoMax1" >
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Tarifa Autorizada p. Aeropuerto Nacional</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" id="tarNacio1">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Tarifa Autorizada p. Aeropuerto internacional</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" id="tarInter1">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Total Servicio Plat. de Embarque Y Desembarque</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" id="total1" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <p style="color: #585858; font-size: 1.2rem; font-weight: bold; line-height: 1rem;">
                                                        SERVICIO DE ESTACIONAMIENTO EN PLATAFORMA DE PERMANENCIA PROLONGADA O PERNOCTA
                                                    </p>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: 1%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Peso máximo operacional de despegue PMOD</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" id="pesoMax2" >
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Tarifa Autorizada p. Aeropuerto Nacional</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" id="tarNacio2" >
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Tarifa Autorizada p. Aeropuerto Internacional</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" id="tarInter2">
                                                    </div>
                                                    <div class="input-group input-group-sm mb-3" style="margin-top: -3%;">
                                                        <span class="input-group-text" id="inputGroup-sizing-sm" style="background-color: aliceblue; height: 23px;">Total serv. de estac. de plataf. prolongada y pernocta</span>
                                                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" style="height: 23px;" id="total2" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                    </form>
                </center>
                </section><br><br><br>

                <!-- <section style="background-color: rgba(132, 220, 255, 0.479); padding-top: 1%; padding-bottom: 0.2%;">
                    <p style="color: rgb(94, 94, 94);"> © 2023 Humanergy · Todos los derechos reservados</p>
                </section> -->
            </div>
            <!-- ============================================================== -->
            <!-- End Wrapper -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- customizer Panel -->
            <!-- ============================================================== -->
            <?php include('ajuste-menu.php') ?>
            <!-- ============================================================== -->
            <!-- All Jquery -->
            <!-- ============================================================== -->
            <?php include('footer-librerias.php') ?>


            <!-- LA entrada contiene el tipo de cambio-->
            <input type="text" id="cambio" style="display:none" value="" > 
           
            <!-- OPERACIONES SQL PARA CATALOGOS-->
            <?php
                //OBTIENE INFORMACION DE CATALOGO DE ATERRIZAJE
                $query = $mysqli -> query ("SELECT * FROM gaf_serv_aeroportuarios");
                $aeropuertoArray = array();
                while ($valores = mysqli_fetch_array($query)) {
                    $aeropuertoArray[] = $valores['idServicio'];
                    $aeropuertoArray[] = $valores['tipo']; 
                    $aeropuertoArray[] = $valores['idAeropuerto'];
                    $aeropuertoArray[] = $valores['tarifa']; 
                }
                $resArray=$aeropuertoArray;
            ?>
            

            <script>
            // -----------------------------------------------------------------------
            //ABORDADORES CALCULO
            var tiempoC = document.getElementById("tiempoAbor"); 
            var totalA = document.getElementById("totalA"); //Total 
            //var totalAbor = document.getElementById("totalAbor1"); //Total de abordadores 
            var totalAbor1 = document.getElementById("totalAbor1"); //Total de abordadores 

            var tiempoCone = document.getElementById("tiempoCone"); 
            var periodo30 = document.getElementById("periodo30"); 
            var periodo15 = document.getElementById("periodo15"); 
            var tarifaAuto = document.getElementById("tarifaAuto"); 

            function totalAbordadores(){
                
                let idAero = idAeropuerto.value;
                let tiempoCC = tiempoC.value;
                let tiempoC1 = tiempoCC;
                let tarifaA; //Tarifa Autorizada
                let cantidadA = totalA.value; //Cantidad de abordadores
                let totala = totalAbor1.value;
                let tipoN = tipo.value;
                let total;

                console.log (totala);

                let tarifaN = tarifaAeropuer(idAero, "NACIONAL", '3');
                let tarifaI = tarifaAeropuer(idAero, "INTERNACIONAL", '3');

                let tiempo30 = tiempoCC / 30;
                let tiempo15 = tiempoCC / 15;   
                
                if (cantidadA != null){
                tiempo30 = Math.ceil(tiempo30); //Calculo por 30 m
                tiempo15 = Math.ceil(tiempo15); //Calculo por 15 m
                }

                if (tipoN == 'NACIONAL'){
                    tarifaA =  tarifaN;
                    //tarifaA * tiempo30 + tarifaA + tiempo15 * totala
                    total = tarifaN * tiempo30 + tarifaN * tiempo15 * totala;
                    tarifaAuto.value = tarifaN;
                    totalA.value = total.toFixed(3);
                } else {
                    tarifaA =  tarifaI
                    //console.log ("tarifaA: ", tarifaI, " t30 ", tiempo30, " tariaA: ", tarifaI, " t15 ", tiempo15, " carb: ", totala);
                    total = tarifaI * tiempo30 + tarifaI * tiempo15 * totala;
                    tarifaAuto.value = tarifaI;
                    //console.log (total);
                    totalA.value = total.toFixed(3);
                }

                tiempoCone.value = tiempoC1;
                periodo30.value = tiempo30;
                periodo15.value = tiempo15;
               
            }

            //-----------------------------------------------------------
            //CALCULO DE TUA
            var exeNac =document.getElementById('exeNac');
            var exeInt =document.getElementById("exeInt");
            var totalNac =document.getElementById("totalNac");
            var totalInt =document.getElementById("totalInt");

            var pasaInter = document.getElementById("pasaInter");  //pasajeros internacionales
            var pasaNac = document.getElementById("pasaNac");  //pasajeros nacionales
            //------------------------

            var tipoCambio = document.getElementById("tipoCambio");
            var tuaPIR = document.getElementById("tuaPIR");
            var tuaPNR = document.getElementById("tuaPNR");
            var totalTNR = document.getElementById("totalTNR");
            var totalTIR = document.getElementById("totalTIR");
            var totalTUA = document.getElementById("totalTUA");
            //var tipoCambio = document.getElementById("tipoCambio");

            function calculoTUA(){
            totalNac.value = pasaNac.value - exeNac.value
            totalInt.value = pasaInter.value - exeInt.value
            //----------------------------
            let pasajerosNacionales = pasaNac.value; //VARIABLES DE TABLA
            let pasajerosNacionalesExentos = exeNac.value; //VARIABLES DE TABLA
            let pasajerosInternacio = pasaInter.value; //VARIABLES DE TABLA
            let pasajerosInternacioExentos = exeInt.value; //VARIABLES DE TABLA

            let tipoc = tipoCambio.value;
            let tcambio = tipoCambio.value;
            let idAero = idAeropuerto.value;
            let tarifaNacional = tarifaAeropuer(idAero, "NACIONAL", '8'); 
            let tarifaInter = tarifaAeropuer(idAero, "INTERNACIONAL", '8'); 
            //console.log ("na:", tarifaNacional, " ti ", tarifaInter);
            tarifaInter *= tipoc;
            let a = parseInt(pasajerosNacionales) - parseInt(pasajerosNacionalesExentos);
            let b = parseInt(pasajerosInternacio) - parseInt(pasajerosInternacioExentos);
            //console.log ("a", a, " b", b);
            let total = (tarifaNacional*a)+((tarifaInter*b)*tcambio);
            let totalNaci = tarifaNacional * (pasajerosNacionales-pasajerosNacionalesExentos);
            let totalInter = tarifaInter * (pasajerosInternacio-pasajerosInternacioExentos);

            totalTUA.value = total.toFixed(3);
            totalTIR.value = totalInter.toFixed(3);
            totalTNR.value = totalNaci.toFixed(3);
            tuaPNR.value = pasajerosNacionales - pasajerosNacionalesExentos;
            tuaPIR.value = pasajerosInternacio - pasajerosInternacioExentos;


            }
            




            //-----------------------------------------------------------
            //INSPECCION DE EQUIPAJE FACTURADO
            
            var tarifaNa = document.getElementById("tarifaNa"); //Peso 
            var tarifaInt = document.getElementById("tarifaInt"); //Peso 
            var totalpas = document.getElementById("totalpas"); //Peso 
            var totalInp = document.getElementById("totalInp"); //Peso 
            
            var a = document.getElementById("pasaNac");
            var b = document.getElementById("pasaInter");
            var c = document.getElementById("exeNac");
            var d = document.getElementById("exeInt");

            function equipaje(){
                let idAero = idAeropuerto.value;
                let pasajeroN = a.value;
                let pasajeroI = b.value;
                let pasajeroEN = c.value;
                let pasajeroEI = d.value;
                //console.log ("pn", pasajeroN, " pi ", pasajeroI, " en ", pasajeroEN, " ei ", pasajeroEI)
                
                let tarifaI = tarifaAeropuer(idAero, "INTERNACIONAL", '7');
                let tarifaN = tarifaAeropuer(idAero, "NACIONAL", '7');

                let totalPN = parseInt(pasajeroN) - parseInt(pasajeroEN);
                let totalPI = parseInt(pasajeroI) - parseInt(pasajeroEI);
                //console.log ("pn: ", totalPN , " pi: ", totalPI);

                let total = (tarifaN * totalPN) + (totalPI * tarifaI);
                
                //Vista
                tarifaNa.value = tarifaN;
                tarifaInt.value = tarifaI;
                totalpas.value = totalPN + totalPI;
                totalInp.value = total.toFixed(3);

            }

            //-----------------------------------------------------------
            //SERVICIO DE ATERRIZAJE
            //DECLARACION DE VARIABLES GLOBALES 
            var pesoMLW = document.getElementById("pesoMLW"); //
            var precioNa = document.getElementById("precioNa");  //
            var precioIa = document.getElementById("precioIa"); // 
            var totalAterrizaje = document.getElementById("totalAterrizaje"); //  
            var tipo = document.getElementById("tipo");//
            var idAeropuerto = document.getElementById("aeropuerto");//
            
            //LA FUNCION CALCULA la tarifa del vuelo
            function tarifaAeropuer(idAero, varTipo, idser){
                let arrayJS=<?php echo json_encode($resArray);?>;
                let tarifa;
                for(let i=0;i<arrayJS.length;i++)
                { 
                    if (arrayJS[i] == idser && arrayJS[i+1] == varTipo && arrayJS[i+2] == idAero){   
                       // console.log ("idServicio: ", arrayJS[i], " tipo: ", arrayJS[i+1], " idAeropuer: ", arrayJS[i+2], " tarifa: ", arrayJS[i+3]);
                        tarifa = arrayJS[i+3];
                       i+=3;
                    }
                }
                //console.log ("salida", tarifa);
                return tarifa;
            }

            function aterrizaje(){
                let idAero = idAeropuerto.value;
                let peso = pesoMLW.value;
                let tipoN = tipo.value;
                let tarifaN = tarifaAeropuer(idAero, "NACIONAL", '1');
                let tarifaI = tarifaAeropuer(idAero, "INTERNACIONAL", '1');
                let total;

                if (tipoN == 'NACIONAL'){
                     total = peso * tarifaN;
                } else {
                    total = peso * tarifaI;
                }

                precioNa.value = tarifaN;
                precioIa.value = tarifaI;
                totalAterrizaje.value = total.toFixed(3);
            }

            //---------------------------------------------------------


                    //Tiempos base calculados
        var fechaI = document.getElementById("fechaI")
        var horaI =document.getElementById("horaI")
        var fechaT =document.getElementById("fechaT")
        var horaT =document.getElementById("horaT")
        var tiempoPer =document.getElementById("tiempoPer")
        function pernocta() {
            let diaI =fechaI.value.substr(0,2)
            let mesI =fechaI.value.substr(3,2)
            let anioI = fechaI.value.substr(6,4)
            let horaIn = horaI.value.substr(0,2)
            let minutoIn =horaI.value.substr(3,2)
            let diaT =fechaT.value.substr(0,2)
            let mesT =fechaT.value.substr(3,2)
            let anioT = fechaT.value.substr(6,4)
            let horaTe = horaT.value.substr(0,2)
            let minutoTe =horaT.value.substr(3,2)
            let ingreso = new Date(anioI,mesI,diaI,horaIn,minutoIn,0)
            let termino = new Date(anioT,mesT,diaT,horaTe,minutoTe,0)
            let pernocta = ((termino-ingreso)/1000)
            pernocta = pernocta / 60
            tiempoPer.value =pernocta
        }


        //CALCULO DE TIEMPO EN PLATAFORMA

        var hentrada = document.getElementById("hentrada");  //Hora de entrada
            var hsalida = document.getElementById("hsalida");  //Hora de salida

            var tiempoCone = document.getElementById("tiempoCone");  //Tiempo de conexion
            var periodo30 = document.getElementById("periodo30");  //Periodo 30'
            var periodo15 = document.getElementById("periodo15");  //Tiempo de conexion
            var tarifaAuto1 = document.getElementById("tarifaAuto");  //Tarifa Autorizada
            var totalAbor = document.getElementById("totalAbor");  //Tarifa Autorizada
            var totalA = document.getElementById("totalA");  //Total
            var tiempoPl = document.getElementById('tiempoPl')
            function tiempoP(){

                //Calculo el total
                // let tiempoC = tiempoCone.value;
                // let tarifaAuto = tarifaAuto1.value;
                // let rfecha30 = periodo30.value;
                // let rfecha15 = periodo15.value;
                // let abordadores = totalAbor.value;
                // let total = tarifaAuto*rfecha30+tarifaAuto*rfecha15*abordadores;
                // console.log("t", total);
                // totalA.value = total;
                let minutosE = hentrada.value.substr(3,2)
                let minutosS = hsalida.value.substr(3,2)
                let horasE = hentrada.value.substr(0,2)
                let horasS = hsalida.value.substr(0,2)
                let hoy = new Date()
                let fechaE = new Date(hoy.getFullYear(),hoy.getMonth(),hoy.getDate(),horasE,minutosE,0)
                let fechaS = new Date(hoy.getFullYear(),hoy.getMonth(),hoy.getDate(),horasS,minutosS,0)
                let plataforma = ((fechaS-fechaE)/1000)
                plataforma =plataforma/60
                tiempoPl.value =plataforma
                console.log(plataforma)
                servPlat()
            }

            //Servicios estacionamiento y plataforma
var pesoMax1 = document.getElementById("pesoMax1")
    var tarNacio1 = document.getElementById("tarNacio1")
    var tarInter1 = document.getElementById("tarInter1")
    var total1 = document.getElementById("total1") 

    var pesoMax2 = document.getElementById("pesoMax2")
    var tarNacio2 = document.getElementById("tarNacio2")
    var tarInter2 = document.getElementById("tarInter2")
    var total2 = document.getElementById("total2")

    var Aeronave =document.getElementById('Aeronave')
    var tipo =document.getElementById("tipo")
    function servPlat() {
        var nave =document.getElementById("aero"+Aeronave.value)
        var totalServ

        if (tipo.value == 'NACIONAL') {
            tarInter1.value =""
            tarInter2.value =""
            var tar =document.getElementById("NACIONAL")
            totalServ =nave.value*tar.value*tiempoPl.value
            tarNacio1.value =tar.value
            pesoMax1.value =nave.value

            tarNacio2.value =tar.value
            pesoMax2.value =nave.value

            total1.value = totalServ
            total2.value = totalServ
        } else if(tipo.value == 'INTERNACIONAL'){
            tarNacio1.value =""
            tarNacio2.value =""
            var tar =document.getElementById("INTERNACIONAL")
            totalServ =parseInt(nave.value*tar.value*tiempoPl.value)
            tarInter1.value =tar.value
            pesoMax1.value =nave.value

            tarInter2.value =tar.value
            pesoMax2.value =nave.value

            total1.value = totalServ
            total2.value = totalServ
        }
        
    }

            </script>

 

</body>

</html>