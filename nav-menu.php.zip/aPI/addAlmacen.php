<?php
    public function addAlmacen(Request $request){

        $colonia = $request->colonia;
        $calle =$request->calle;
        $numero_exterior = $request->numero_exterior;
        $numero_interior = $request->numero_interior;
        $municipio= $request->municipio;
        $estado = $request->estado;
        $pais = $request->pais;
        $telefono = $request->telefono;
        $correo = $request->correo;
        $responsable = $request->responsable;
        $cp = $request->cp;

        
        DB::insert('INSERT INTO s4y_producto (colonia, calle, numero_exterior, numero_interior, municipio,estado, pais, telefono, correo, responsable) 
        VALUES (?,?,?,?,?,?,?,?,?,?,?)', [$colonia, $calle, $numero_exterior, $numero_interior, $cp, $municipio, $estado, $pais, $telefono, $correo, $responsable]);

        return response()->json([
            'message' => 'Bien',
        ]);
    }

    //Route
    Route::post('/addAlmacen', 'App\Http\Controllers\ApiController@addAlmacen');

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///////FUNCION PARA ACTUALIZAR ALMACEN///////////////////////////////////////////////////////////////

    public function upAlmacen(Request $request){

        $id= $request->id;
        $colonia = $request->colonia;
        $calle =$request->calle;
        $numero_exterior = $request->numero_exterior;
        $numero_interior = $request->numero_interior;
        $municipio= $request->municipio;
        $estado = $request->estado;
        $pais = $request->pais;
        $telefono = $request->telefono;
        $correo = $request->correo;
        $responsable = $request->responsable;
        $cp = $request->cp;

        
        DB::insert('UPDATE  erp_alamcen SET colonia=?, calle=?, numero_exterior=?, numero_interior=?,  cp=?, municipio=?, estado=?, pais=?, telefono=?, correo=?, responsable=? WHERE id=?',
        [$colonia, $calle, $numero_exterior, $numero_interior,  $municipio, $estado, $pais, $telefono, $correo, $responsable, $cp]);

        return response()->json([
            'message' => 'Bien',
        ]);
    }

    //Route
    Route::post('/upAlmacen', 'App\Http\Controllers\ApiController@upAlmacen');

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //API PARA AGREGAR VIDEOS A MYDIGITALSHAKE  DEL DASHBOARD///////////
    public function addDigitalShakeGratis(Request $request){

        $idUsuario = $request->idUsuario;
        $idVideo =$request->idVideo;


        
        DB::insert('INSERT INTO erp_usuario_has_video (id,idUsuario, idVideo, fecha) 
        VALUES (?,?,?,?)', [null,$idUsuario, $idVideo, NOW()]);

        return response()->json([
            'message' => 'Bien',
        ]);
    }

    //Route
    Route::post('/addAlmacen', 'App\Http\Controllers\ApiController@addDigitalShakeGratis');
?>
