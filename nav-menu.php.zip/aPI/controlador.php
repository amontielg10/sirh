<?php
//REALIZAR COMPRA
public function compra(Request $request){
    /*/
    *
    *SE OBTIENE VALORES DE DESCUENTOS Y COMISIONES, DESDE BASE DE DATOS
    *
    /*/
    //DESCUENTO A AFILIADOS
    $sql_descuento = "SELECT cantidad FROM `erp_descuentos_comisiones` WHERE tipo = 'DESCUENTO_AFILIADOS' ";
    $get_descuento = DB::select($sql_descuento);
    foreach($get_descuento as $for_descuento){
        $descuentoAux = $for_descuento->cantidad;
    }
    $descuentoAfiliados = $descuentoAux;
    
    //COMISION DE PASARELA DE PAGO
    $sql_comision_pasarela = "SELECT cantidad FROM `erp_descuentos_comisiones` WHERE tipo = 'COMISION_PASARELA' ";
    $get_comision_pasarela = DB::select($sql_comision_pasarela);
    foreach($get_comision_pasarela as $for_comision_pasarela){
        $comision_pasarelaAux = $for_comision_pasarela->cantidad;
    }
    $comision_pasarela = $comision_pasarelaAux;
    //COMISION SHAKE4YOU POR COMPRA DE A TRAVES DE ENLACE COMPARTIDO
    $sql_comision_enlace_compartido = "SELECT cantidad FROM `erp_descuentos_comisiones` WHERE tipo = 'COMISION_S4Y_ENLACE_COMPARTIDO' ";
    $get_comision_enlace_compartido = DB::select($sql_comision_enlace_compartido);
    foreach($get_comision_enlace_compartido as $for_comision_enlace_compartido){
        $comision_enlace_compartidoAux = $for_comision_enlace_compartido->cantidad;
    }
    $comision_enlace_compartido = $comision_enlace_compartidoAux;
    //COMISION SHAKE4YOU POR COMPRA DE UN REFERIDO (NIVEL 2)
    $sql_comision_referido = "SELECT cantidad FROM `erp_descuentos_comisiones` WHERE tipo = 'COMISION_S4Y_REFERIDOS' ";
    $get_comision_referido = DB::select($sql_comision_referido);
    foreach($get_comision_referido as $for_comision_referido){
        $comision_referidoAux = $for_comision_referido->cantidad;
    }
    $comision_referido = $comision_referidoAux;
    
    //SE RECIBEN VALORES DE API
    $ordenS4Y = '#OrdenS4Y-'.now()->timestamp;
    $ordenEnviosPerros = $request->ordenEnviosPerros;
    $guiaPDF2 = $request->guiaPDF;
    $paqueteria = $request->paqueteria;
    $incluye = $request->incluye;
    $idUsuario = $request->idUsuario;
    $total_canasta = floatval($request->total_canasta);
    $descuento = floatval($request->descuento);
    $subtotal = floatval($request->subtotal);
    $costoPaqueteria = floatval($request->costoPaqueteria);
    $pago_paqueteria = floatval($request->pago_paqueteria);
    $total_percepciones = floatval($request->total_percepciones);
    
    $referBy = $request->referBy;
    $idPC = $request->idPC;
    $idCupon = $request->idCupon;
    $nombre = $request->nombre;
    $app = $request->app;
    $apm = $request->apm;
    $telefono = $request->telefono;
    $correo = $request->correo;
    $cp = $request->cp;
    $estado = $request->estado;
    $municipio = $request->municipio;
    $colonia = $request->colonia;
    $calle = $request->calle;
    $numero_exterior = $request->numero_exterior;
    $numero_interior = $request->numero_interior;
    $referencias = $request->referencias;
    //Agregado ID Almacen   
    $idAlmacen = $request->idAlmacen;
    //
    $status = "PROCESO";
    //PODUCTOS EN COMPRA
    $productos = $request->productos;
    //ASEGURAR CADENA BASE64 SEGURA
    $guiaPDF = str_replace(" ","+",$guiaPDF2);
    /**
     * INSERCION EN BD DE COMPRA
     */
    DB::insert('INSERT INTO `s4y_orders` (`id`, `ordenS4Y`, `ordenEnviosPerros`, `guiaPDF`, `paqueteria`, `incluye`, `idUsuario`,`total_canasta`,`descuento`, `subtotal`,`costoPaqueteria`,`pago_paqueteria`, `com_stripe`,`com_s4y`, `total_percepciones`,`refer_by`, `idPC`, `idCupon`, `nombre`, `app`, `apm`, `telefono`, `correo`, `cp`, `estado`, `municipio`, `colonia`, `calle`, `numero_exterior`, `numero_interior`, `referencias`, `STATUS`, `created_at`, `updated_at`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, NOW(),NOW());',
    [null,$ordenS4Y,$ordenEnviosPerros,$guiaPDF,$paqueteria,$incluye,$idUsuario,$total_canasta,$descuento,$subtotal,$costoPaqueteria,$pago_paqueteria,($total_percepciones*$comision_pasarela/100),0,$total_percepciones,$referBy,$idPC,$idCupon,$nombre,$app,$apm,$telefono,$correo,$cp,$estado,$municipio,$colonia,$calle,$numero_exterior,$numero_interior,$referencias,$status]);

    /**
     * MODIFICACION DE STOCK POR CADA PRODUCTO COMPRADO. PARA ESTE PASO, SE HA CREADO UN 
     * PROCEDIMIENTO Y UN TRIGGER EN BD, QUE AUTOMÁTICAMENTE, AL AGREGAR LOS PRODUCTOS EN LA
     * TABLA 's4y_order_line', ACTUALIZA SU STOCK. PARA HACER ESTO, PRIMERO CONSULTAMOS EL 
     * ID DE LA ULTIMA COMPRA REALIZADA ('s4y_orders').
     */
    
    /**
     * OBTENEMOS LOS DATOS RECIEN AGREGADOS EN BD, PARA MANDAR LOS CORREOS CORRESPONDIENTES
     */
      $obtenerOrden = "SELECT * FROM `s4y_orders` ORDER BY id DESC LIMIT 1;";
      $idOrden = DB::select($obtenerOrden);
      foreach($idOrden as $id){
        $idOrderaux = $id->id;
        $ordenS4Yaux = $id->ordenS4Y;
      }
      $idOrder = $idOrderaux;//ID DE LA ORDEN ACTUAL
      $orS4y = $ordenS4Yaux;//CODIGO DE COMPRA DE LA ORDEN ACTUAL
      /*
       * VERIFICACION DE ESCENARIOS DE COMPRA 
       */
       if(is_null($idUsuario)){
           /**
            * SE GUARDA DATOS EN TABLAS EN s4y_order_line
            */
            foreach($productos as $producto=>$valor){
                //$idOrder;
                $idP = $valor['id'];
                $precio = $valor['price'];
                $costo = $valor['cost'];//
                $cantidad = $valor['qty'];
                DB::select('call ordenItem(?,?,?,?,?,?,?,?)',array($idOrder,$idP,$costo,$precio,$cantidad,($precio*$cantidad),0,($precio*$cantidad)));
                //DB::insert('INSERT INTO erp_kardex (id,fecha,factura_venta,idAlmacen,idProducto,cantidad,tipo,razon) VALUES (?,?,?,?,?,?,?,?)',
                //[null,NOW(),$orS4y,1,$idP,$cantidad,'SALIDA','VENTA']);
              }
           
           /**
            * ESCENARIO 1: Publico en general. Sin ninguna comision ni descuento
            */
             
            //SE DEFINEN VALORES PARA CAMPOS TOTAL_DEDUCCIONES Y NETO, SIN COMISIONES NI DESCUENTOS
            $total_deducciones = $pago_paqueteria+($total_percepciones*$comision_pasarela/100)+0; // PAGO PAQUETERIA + COMISION DE PASARELA DE PAGO + COMISION DE SHAKE4YOU
            $neto = $total_percepciones-$total_deducciones;
            DB::update('UPDATE s4y_orders SET total_deducciones = ?, NETO = ? WHERE id = ?', [$total_deducciones,$neto,$idOrder]);
           if(is_null($referBy)){
               //NO GENERA COMISION NI DESCUENTOS
           }else{
               /**
                * ESCENARIO 2: Publico en general con enlace de compra. Se genera comisión del 10%
                */
               DB::update('UPDATE s4y_orders SET com_s4y = ? WHERE id = ?',[($subtotal*$comision_enlace_compartido/100),$idOrder]);
               //$total_deducciones = $pago_paqueteria+($pago_paqueteria);// pago paqueteria + comision de pasarela + comision de Shake4You
               $getIdUsrCOM = "SELECT id FROM `s4y_usuarios` WHERE cod_afi = '$referBy';";
               $getIdCom = DB::select($getIdUsrCOM);
               foreach($getIdCom as $getComId){
                   $idComision = $getComId->id;
                   DB::insert('INSERT INTO erp_comisiones (id,idOrder,idUsuario,comision,razon,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)',
                   [null,$idOrder,$idComision,($subtotal*$comision_enlace_compartido/100),'ENLACE COMPARTIDO','PENDIENTE',NOW(),NOW()]);
               }
               //SE DEFINEN VALORES PARA CAMPOS TOTAL_DEDICCIONES Y NETO, PERO CON COMISION POR ENLACE COMPARTIDO
               $total_deducciones = $pago_paqueteria + ($total_percepciones*$comision_pasarela/100) + ($subtotal*$comision_enlace_compartido/100) ; //PAGO PAQUETERIA + COMISION DE PASARELA DE PAGO + COMISION DE SHAKE4YOU
               $neto = $total_percepciones - $total_deducciones;
               DB::update('UPDATE s4y_orders SET total_deducciones = ?, NETO = ? WHERE id = ?', [$total_deducciones,$neto,$idOrder]);
           }
       }else{
           /**
            *  INICIA LA VERIFICACIÓN SI EL USUARIO TIENE DIRECCIÓN REGISTRADA
            */
            $sqlAdd = "SELECT COUNT(*) contar FROM `s4y_direcciones` WHERE idUsuario=$idUsuario";
            $resultAdd = DB::select($sqlAdd);
            foreach($resultAdd as $d){
                $countAux = $d->contar;
            }
            $count = intval($countAux);
            if($count < 1){
                DB::insert('INSERT INTO s4y_direcciones (idUsuario,cp,estado,municipio,colonia,calle,numeroExterior,numeroInterior,referencias) VALUES(?,?,?,?,?,?,?,?,?)',
                [$idUsuario,$cp,$estado,$municipio,$colonia,$calle,$numero_exterior,$numero_interior,$referencias]);
            }
            /**
             * TERMINA VERIFICACION
             */
             
           /**
            * SE GUARDA DATOS EN TABLA s4y_order_line
            */
            foreach($productos as $producto=>$valor){
                //$idOrder;
                $idP = $valor['id'];
                $precio = $valor['price'];
                $costo = $valor['cost'];//
                $cantidad = $valor['qty'];
                DB::select('call ordenItem(?,?,?,?,?,?,?,?)',array($idOrder,$idP,$costo,$precio,$cantidad,($precio*$cantidad),(($precio*$cantidad)$descuentoAfiliados/100),(($precio$cantidad)-(($precio*$cantidad)*$descuentoAfiliados/100))));
                //DB::insert('INSERT INTO erp_kardex (id,fecha,factura_venta,idAlmacen,idProducto,cantidad,tipo,razon) VALUES (?,?,?,?,?,?,?,?)',
                //[null,NOW(),$orS4y,1,$idP,$cantidad,'SALIDA','VENTA']);
              }
            
            // SE IDENTIFICA SI EL AFILIADO ES NIVEL 1 O 2
            $getReferId = "SELECT * FROM `s4y_usuarios` WHERE id = '$idUsuario';";
            $getRId = DB::select($getReferId);
            foreach($getRId as $getIdRef){
               $cod_refer = $getIdRef->refer_by;
               
               if(is_null($cod_refer)){
                   /**
                     * ESCENARIO 3: Compra de afiliado. (20% descuento)
                     */
                    //SE DEFINEN VALORES PARA CAMPOS TOTAL_DEDUCCIONES Y NETO, SIN COMISIONES
                    $total_deducciones = $pago_paqueteria+($total_percepciones*$comision_pasarela/100)+0; // PAGO PAQUETERIA + COMISION DE PASARELA DE PAGO + COMISION DE SHAKE4YOU
                    $neto = $total_percepciones-$total_deducciones;
                    DB::update('UPDATE s4y_orders SET total_deducciones = ?, NETO = ? WHERE id = ?', [$total_deducciones,$neto,$idOrder]);
               }else{
                   /**
                     * ESCENARIO 4: Compra de afiliado => 2° nivel. (20% descuento + 10% comision a nivel 1)
                     */
                     DB::update('UPDATE s4y_orders SET com_s4y = ? WHERE id = ?',[($subtotal*$comision_referido/100),$idOrder]);
                    $obtUsCOM = "SELECT id FROM s4y_usuarios WHERE cod_afi = '$cod_refer'";
                    $obtCOM = DB::select($obtUsCOM);
                    foreach($obtCOM as $obID){
                        $idUsuarioComision = $obID->id;
                        DB::insert('INSERT INTO erp_comisiones (id,idOrder,idUsuario,comision,razon,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)',
                    [null,$idOrder,$idUsuarioComision,($subtotal*$comision_referido/100),'REFERIDOS','PENDIENTE',NOW(),NOW()]);
                    }
                    //SE DEFINEN VALORES PARA CAMPOS TOTAL_DEDUCCIONES Y NETO, SIN COMISIONES
                    $total_deducciones = $pago_paqueteria+($total_percepciones*$comision_pasarela/100)+($subtotal*$comision_referido/100); // PAGO PAQUETERIA + COMISION DE PASARELA DE PAGO + COMISION DE SHAKE4YOU
                    $neto = $total_percepciones-$total_deducciones;
                    DB::update('UPDATE s4y_orders SET total_deducciones = ?, NETO = ? WHERE id = ?', [$total_deducciones,$neto,$idOrder]);
                    
               }
           }
           
       }
       /**
        * 
        */
      /*foreach($productos as $producto=>$valor){
        //$idOrder;
        $idP = $valor['id'];
        $precio = $valor['price'];
        $costo = $valor['cost'];//
        $cantidad = $valor['qty'];
        DB::select('call ordenItem(?,?,?,?)',array($idOrder,$idP,$precio,$cantidad));
      }*/
      /**
       * OBTENEMOS CUENTA DE CORREO DE ALMACEN
       */
      /**OBTENEMOS EL ID DEL ALMACÉN PARA SABER A QUE ALMACEN SE MANDA EL PEDIDO */
      $getCorreoAlmacen = "SELECT url FROM erp_urls WHERE tipo = 'CORREO-ALMACEN'";
      $queryCorreoAlmacen = DB::select($getCorreoAlmacen);
      foreach($queryCorreoAlmacen as $correoAl){
        $correoAlmacenAux = $correoAl->url;
      }
      $correoAlmacen = $correoAlmacenAux;
     /**
      * ENVIO DE CORREO A USUARIO
      */
      $mailCompra = new CompraCliente($productos,$orS4y);
      Mail::to($correo)->send($mailCompra);
      /**
       * ENVIO DE CORREO A ALMACEN
       */
      $mailAlmacen = new PedidoAlmacen($productos,$orS4y,$guiaPDF,$ordenEnviosPerros);
      Mail::to($correoAlmacen)->send($mailAlmacen);
      return response()->json([
        'message' => 'Sale made successfully!',
    ], 201);
}
?>