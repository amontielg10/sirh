<?php
//FUNCION PARA AÑADIR CATEGORIA
    public function addCategoriaMaterial(Request $request){

        $nombre = $request->nombre;
        $descripcion =$request->descripcion;
   
        DB::insert('INSERT INTO erp_categoria_materialD (nombre, descripcion,  status) 
        VALUES (?,?,?)', [$nombre, $descripcion,  0]);
        return response()->json([
            'message' => 'Bien',
        ]);
    }

    //ROUTE PARA AÑADIR CATEGORIA
    Route::post('/addCategoria', 'App\Http\Controllers\ApiController@addCategoria');
    
    /////////////////////////////////////////////////////////////////////////
    /////////*********ACTUALIZAR CATEGORIA****** */
    //FUNCION PARA ACTUALIZAR CATEGORIA
    public function upCategoria(Request $request){
        
        $id=$request->id;
        $nombre = $request->nombre;
        $descripcion = $request->descripcion;

        DB::update('UPDATE s4y_categoria SET nombre=?, descripcion=?, seccion=? WHERE id=?', [$nombre, $descripcion, $id]);
        return response()->json([
            'message' => 'categoria actualizado',
        ]);
    }
    //ROUTE PARA ACTUALIAZR CATEGORIA
    Route::post('/upCategoria','App\Http\controllers\ApiController@upCategoria');

?>
