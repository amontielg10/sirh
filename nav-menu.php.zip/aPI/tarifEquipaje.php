<?php  
$curl = curl_init();
curl_setopt_array($curl, [
CURLOPT_URL => "https://api.paeroportuario.humanergy.app/api/allServAeroportuariosByAeropuerto/1",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_ENCODING => "",
CURLOPT_MAXREDIRS => 10,
CURLOPT_TIMEOUT => 30,
CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
CURLOPT_CUSTOMREQUEST => "GET",
CURLOPT_POSTFIELDS => "",
CURLOPT_HTTPHEADER => [
    "User-Agent: insomnia/2023.5.8"
],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
echo "cURL Error #:" . $err;
} else {
    $datos= json_decode($response, true);
    foreach ($datos as $dato) {
        // echo "idcategoria: ".$dato['id']."<br>";
        // echo "idcategoria: ".$dato['servicio']."<br>";
        // echo "idcategoria: ".$dato['tipo']."<br>";
        // echo "idcategoria: ".$dato['tarifa']."<br>";
        // echo "________ <br>";
        if($dato['id']==1){ //equipaje Na
                $precioNE = $dato['tarifa'];
                // echo "________ <br>";
            }
            elseif($dato['id']==2){ //equipaje In
                $precioIE = $dato['tarifa'];
                // echo "________ <br>";
            }
            elseif($dato['id']==3){ //terrizaje N
                $precioNA = $dato['tarifa'];
                // echo "________ <br>";
            }
            elseif($dato['id']==4){ //aterrizaje In
                $precioIA = $dato['tarifa'];
                // echo "________ <br>";
            }
    }
}
?>