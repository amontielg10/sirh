<?php
    public function updUser(Request $request){
        $id=$request->id;
        $idperfil = $request->idperfil;
        $nombre = $request->nombre;
        $app =$request->app;
        $apm= $request->apm;
        $correo = $request->correo;
        $foto = $request->foto64;

        
        DB::update('UPDATE  erp_usuarios SET idPerfil=?, nombre =?, app=?, apm=?, correo=?, foto=?, status=? WHERE id=?',
        [$idperfil, $nombre,$app,$apm, $correo,$foto, 1, $id]);

        return response()->json([
            'message' => 'Bien',
        ]);
    }

    //Route
    Route::post('/updUser', 'APP\Http\Controllers\ApiController@updUser');
?>
