<?php
    public function addBanner(Request $request){

        $link = $request->link;
        $caducidad =$request->caducidad;
        $seccion = $request->seccion;
        DB::insert('INSERT INTO erp_banners (link, caducidad, seccion, status) 
        VALUES (?,?,?)', [$link, $caducidad, $seccion,  0]);
        return response()->json([
            'message' => 'Bien',
        ]);
    }

    //Route para añadir banner
    Route::post('/addBanner', 'App\Http\Controllers\ApiController@addBanner');
    
    /////////////////////////////////////////////////////////////////////////
    /////////*********ACTUALIZAR BANNER****** */
    //API para actualizar Banner
    public function upBanner(Request $request){
        
        $id=$request->id;
        $link = $request->link;
        $caducidad = $request->caducidad;
        $seccion = $request->seccion;

        DB::update('UPDATE erp_banner SET link=?, caducidad=?, seccion=? WHERE id=?', [$link, $caducidad, $seccion, $id]);
        return response()->json([
            'message' => 'Banner actualizado',
        ]);
    }
    //Route para actualizar banner
    Route::post('/upBanner','App\Http\controllers\ApiController@upBanner');

?>
