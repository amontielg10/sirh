<?php
    public function addProducto(Request $request){

        $idCategoria = $request->idCategoria;
        $nombre = $request->nombre;
        $sku =$request->sku;
        $precio= $request->precio;
        $descripcion = $request->descripcion;
        $descripcionlarga = $request->descripcionlarga;
        $foto = $request->foto;
        $foto_sec1 = $request->foto_sec1;
        $foto_sec2 = $request->foto_sec2;
        $foto_sec3 = $request->foto_sec3;
        $foto_sec4 = $request->foto_sec4;

        
        DB::insert('INSERT INTO s4y_producto (idCategoria, sku, nombre, descripcion, descripcionlarga,precio,foto,foto_sec1,foto_sec2,foto_sec3,foto_sec4, status) 
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', [$idCategoria, $sku, $nombre, $descripcion, $descripcionlarga, $precio,$foto,$foto_sec1,$foto_sec2,$foto_sec3,$foto_sec4, 1]);

        return response()->json([
            'message' => 'Bien',
        ]);
    }

    //Route
    Route::post('/addProducto', 'App\Http\Controllers\ApiController@addProducto');
?>
