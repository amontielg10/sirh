<?php
    public function UserDashID(Request $request)
    {
        $id = $request->id;
        $sql = "SELECT u.nombre, u.app, u.apm, u.correo, u.telefono, u.foto, d.cp, d.estado, d.municipio, d.colonia, d.calle, d.numeroExterior, d.numeroInterior, d.referencias FROM s4y_usuarios u INNER JOIN s4y_direcciones d ON u.id = d.idUsuario WHERE u.id = ?;";
        $userdash = DB::select($sql, array($id));
        return $userdash;
    }

    Route::get('/Userid/{id}', 'App\Http\Controllers\ApiController@Userid');
?>