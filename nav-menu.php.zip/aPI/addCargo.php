<?php
    public function addCuentaxPagar(Request $request){

        $idRequisiciones = $request->idRequisiciones;
        $proveedor = $request->proveedor;
        $concepto =$request->concepto;
        $factura = $request->factura;
        $forma_pago = $request->forma_pago;
        $importe= $request->importe;
        $abonado = $request->abonado;
        $saldo = $request->saldo;
        $status = $request->status;



        
        DB::insert('INSERT INTO erp_cuentasxpagar (idproveedor,idRequisiciones, fecha, concepto, factura, forma_pago, importe, abonado, saldo, status) 
                     VALUES (?,?,?,?,?,?,?,?,?,?)', [$proveedor,$idRequisiciones ,NOW(), $concepto, $factura, $forma_pago, $importe, $abonado, $saldo, $status ]);

        $obteneridCXP = "SELECT * FROM erp_cuentasxpagar ORDER BY id DESC LIMIT 1;";
        $idCXP = DB::select($obteneridCXP);
        foreach($idCXP as $id){
            $idCXPaux = $id->id;            
        }

        DB::insert('INSERT INTO erp_cuentasxpagar_pagos (idCXP, fecha, importe, abono, saldo)
                        VALUES (?,?,?,?,?)', [$idCXPaux, NOW(), $importe, $abonado, $saldo]);
        
        DB::update('UPDATE erp_requisiciones SET status=?, updated_at=? WHERE id=?', ['ATENDIDA', NOW(), $idRequisiciones]);

        return response()->json([
            'message' => 'Bien',
        ]);
    }

    //ROUTE PARA AGREGAR ABONO E HISTORIAL DE ABONO 
    Route::post('/addCuentaxPagar', 'App\Http\Controllers\ApiController@addCuentaxPagar');

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///////FUNCION PARA ACTUALIZAR CUENTAS POR PAGAR ///////////////////////////////////////////////////////////////

    public function upAbonoCuentasxPagar(Request $request){

        $id = $request->id;
        $abono = floatval($request->abono);
        $abonado = floatval($request->abonado);
        $importe =floatval($request->importe);


        DB::insert('INSERT INTO erp_cuentasxpagar_pagos (id, idCXP, fecha, importe, abono, saldo)
                        VALUES (?,?,?,?,?,?)', [NULL, $id, NOW(), $importe, $abono, ($importe-($abonado+$abono))]);


        $saldo=($importe-($abonado+$abono));
        if($saldo > 0){
            $status= 'PENDIENTE';
        }else{
            $status='PAGADA';
        }
        
        DB::update('UPDATE erp_cuentasxpagar SET abonado = ?, saldo = ?, status=? WHERE id=? ',
         [($abonado + $abono), $saldo, $status, $id ]);


        
        return response()->json([
            'message' => 'Bien',
        ]);
    }

    //ROUTE PARA ACTUALIZAR ABONO E HISTORIAL DE ABONO 
    Route::post('/upAbonoCuentasxPagar', 'App\Http\Controllers\ApiController@upAbonoCuentasxPagar');
?>
