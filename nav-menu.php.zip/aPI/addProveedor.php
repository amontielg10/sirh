<?php
    public function addProveedor(Request $request){

        $nombre = $request->nombre;
        $colonia = $request->colonia;
        $calle =$request->calle;
        $numero_exterior = $request->numero_exterior;
        $numero_interior = $request->numero_interior;
        $municipio= $request->municipio;
        $cp = $request->cp;
        $estado = $request->estado;
        $pais = $request->pais;
        $telefono = $request->telefono;
        $correo = $request->correo;
        $contacto = $request->contacto;

        
        DB::insert('INSERT INTO erp_proveedor (nombre, colonia, calle, numero_exterior, numero_interior, municipio, cp, estado, pais, telefono, correo, contacto, status) 
        VALUES (?,?,?,?,?,?,?,?,?,?,?)', [$nombre, $colonia, $calle, $numero_exterior, $numero_interior, $municipio, $cp, $estado, $pais, $telefono, $correo, $contacto, 1]);

        return response()->json([
            'message' => 'Bien',
        ]);
    }

    //Route
    Route::post('/addProveedor', 'App\Http\Controllers\ApiController@addProveedor');

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///////FUNCION PARA ACTUALIZAR PROVEEDOR ///////////////////////////////////////////////////////////////

    public function upProveedor(Request $request){

        $id= $request->id;
        $nombre = $request->nombre;
        $colonia = $request->colonia;
        $calle =$request->calle;
        $numero_exterior = $request->numero_exterior;
        $numero_interior = $request->numero_interior;
        $municipio= $request->municipio;
        $cp = $request->cp;
        $estado = $request->estado;
        $pais = $request->pais;
        $telefono = $request->telefono;
        $correo = $request->correo;
        $contacto = $request->contacto;

        
        DB::insert('UPDATE  erp_proveedor SET colonia=?, calle=?, numero_exterior=?, numero_interior=?,  cp=?, municipio=?, estado=?, pais=?, telefono=?, correo=?, responsable=? WHERE id=?',
        [$colonia, $calle, $numero_exterior, $numero_interior,  $municipio, $estado, $pais, $telefono, $correo, $responsable, $cp]);

        return response()->json([
            'message' => 'Bien',
        ]);
    }

    //Route
    Route::post('/upProveedor', 'App\Http\Controllers\ApiController@upProveedor');
?>
