<?php
//FUNCION PARA ACTUALIZAR STATUS DE REQUISICION
    public function upStatusRequisicion(Request $request){

        
        $autorizo =$request->autorizo;
        $status =$request->status;
        $id = $request->idRequi;
   
        DB::update('UPDATE erp_requisiciones SET  autorizo=?, status=?, updated_at=? WHERE id= ?', 
        [$$autorizo, $status, NOW(), $id]);
        return response()->json([
            'message' => 'Bien',
        ]);
    }

    //ROUTE PARA AÑADIR CATEGORIA
    Route::post('/upStatusRequisicion', 'App\Http\Controllers\ApiController@upStatusRequisicion');
    

?>
