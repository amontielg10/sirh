<?php
    public function upProducto(Request $request){
        $id=$request->id;
        $idCategoria = $request->idCategoria;
        $sku =$request->sku;
        $nombre = $request->nombre;
        $descripcion= $request->descripcion;
        $descripcionlarga = $request->descripcionlarga;
        $precio = $request->precio;
        $foto = $request->foto;
        $foto_sec1 = $request->foto_sec1;
        $foto_sec2 = $request->foto_sec2;
        $foto_sec3 = $request->foto_sec3;
        $foto_sec4 = $request->foto_sec4;



        
        DB::update('UPDATE s4y_producto  SET idCategoria=?, nombre =?, sku=?, descripcion=?, descripcionlarga=?, precio=?, foto=?, foto_sec1=?, foto_sec2=?, foto_sec3=?, foto_sec4=?,  status=? WHERE id=?',
        [$idCategoria, $nombre,$sku,$descripcion, $descripcionlarga,$precio,$foto, $foto_sec1, $foto_sec2, $foto_sec3, $foto_sec4, 1, $id]);

        return response()->json([
            'message' => 'Bien',
        ]);
    }

    //Route
    Route::post('/upProducto', 'APP\Http\Controllers\ApiController@upProducto');
?>
